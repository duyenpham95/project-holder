package com.example.camel001;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Camel001Application {

	public static void main(String[] args) {
		SpringApplication.run(Camel001Application.class, args);
	}

}
